$(document).ready(()=>{
  console.log("document ready")
  $("#year").fitText(0.25);
  $("#day").fitText(0.3);
  $("#month").fitText(0.4);
  $("#title").fitText(2);
})